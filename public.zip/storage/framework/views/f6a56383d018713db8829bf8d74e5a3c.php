<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col items-center justify-center mt-5">
        <h1 class="text-3xl font-bold">Ms Access File Upload</h1>

        <div class="flex flex-col w-1/2 mt-5">
            <form action="/file-upload" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                

                <!-- Report Month Checkboxes -->
                <div class="mb-4 flex flex-col gap-4">
                    <h2 for="start_date" class="block text-sm font-medium leading-6 text-gray-900">Report Month/s:</h2>
                    <div class="flex gap-6">
                        <!-- First Column -->
                        <div class="flex flex-col gap-2">
                            <?php $__currentLoopData = ['January', 'February', 'March']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="checkbox" id="<?php echo e(strtolower($month)); ?>" name="selected_months[]"
                                        value="<?php echo e($month); ?>"
                                        <?php echo e(in_array($month, old('selected_months', [])) ? 'checked' : ''); ?>>
                                    <label for="<?php echo e(strtolower($month)); ?>"><?php echo e($month); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Second Column -->
                        <div class="flex flex-col gap-2">
                            <?php $__currentLoopData = ['April', 'May', 'June']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="checkbox" id="<?php echo e(strtolower($month)); ?>" name="selected_months[]"
                                        value="<?php echo e($month); ?>"
                                        <?php echo e(in_array($month, old('selected_months', [])) ? 'checked' : ''); ?>>
                                    <label for="<?php echo e(strtolower($month)); ?>"><?php echo e($month); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Third Column -->
                        <div class="flex flex-col gap-2">
                            <?php $__currentLoopData = ['July', 'August', 'September']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="checkbox" id="<?php echo e(strtolower($month)); ?>" name="selected_months[]"
                                        value="<?php echo e($month); ?>"
                                        <?php echo e(in_array($month, old('selected_months', [])) ? 'checked' : ''); ?>>
                                    <label for="<?php echo e(strtolower($month)); ?>"><?php echo e($month); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Fourth Column -->
                        <div class="flex flex-col gap-2">
                            <?php $__currentLoopData = ['October', 'November', 'December']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="checkbox" id="<?php echo e(strtolower($month)); ?>" name="selected_months[]"
                                        value="<?php echo e($month); ?>"
                                        <?php echo e(in_array($month, old('selected_months', [])) ? 'checked' : ''); ?>>
                                    <label for="<?php echo e(strtolower($month)); ?>"><?php echo e($month); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php $__errorArgs = ['selected_months'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Report Year Field -->
                <div class="mb-4 flex flex-col">
                    <label for="report_year" class="block text-sm font-medium leading-6 text-gray-900">Report
                        Year:</label>
                    <select name="report_year" id="report_year"
                        class="block w-full rounded-md border-0 py-1.5 pl-3 pr-20 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        <option value="" disabled selected>Select a year</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>" <?php echo e(old('report_year') == $year ? 'selected' : ''); ?>>
                                <?php echo e($year); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['report_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- MDB File Upload -->
                <div class="mb-4">
                    <label class="block mb-2 text-sm font-medium" for="mdbFile">Upload MDB File</label>
                    <input
                        class="block w-full text-lg text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:placeholder-gray-400"
                        id="mdbFile" type="file" name="mdbFile" accept=".mdb">
                    <?php $__errorArgs = ['mdbFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <input
                    class="mt-5 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"
                    type="submit" value="Upload">
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mon\Desktop\FHSIS\resources\views/FileUpload/create.blade.php ENDPATH**/ ?>