<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col flex-grow rounded-lg border bg-card text-card-foreground shadow-sm p-4 border-zinc-800">
        <div class="overflow-auto" style="max-height: 100%;"> <!-- Make the table scrollable here -->
            <table class="w-full table-auto">
                <thead class="bg-white sticky top-0 z-10">
                    <tr>
                        <th class="text-left p-4 bg-white" style="width: 200px;">Municipality</th>
                        <!-- Set a width to align with tbody -->
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="text-center p-4 bg-white" style="width: 100px;"><?php echo e(substr($month, 0, 3)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $municipalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="p-4 border border-zinc-800" style="width: 200px;"><?php echo e($municipality); ?></td>
                            <!-- Keep width consistent -->
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="p-4 text-center border border-zinc-800"
                                    style="width: 100px; background-color:
                                        <?php if(
                                            $files->contains(function ($file) use ($municipality, $month) {
                                                $selectedMonths = json_decode($file->selected_months, true);
                                                return $file->municipality === $municipality && in_array($month, $selectedMonths);
                                            })): ?> green
                                        <?php elseif(
                                            \Carbon\Carbon::parse($month)->isFuture() &&
                                                !$files->contains(function ($file) use ($municipality, $month) {
                                                    $selectedMonths = json_decode($file->selected_months, true);
                                                    return $file->municipality === $municipality && in_array($month, $selectedMonths);
                                                })): ?> grey
                                        <?php else: ?> red <?php endif; ?>;">
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mon\Desktop\FHSIS\resources\views/dashboard_admin.blade.php ENDPATH**/ ?>