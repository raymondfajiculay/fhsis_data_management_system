<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mx-auto flex w-full  flex-col justify-center px-5">
        <h1 class="text-4xl font-bold text-center mt-5">Dashboard</h1>
        

        <div class="flex flex-col flex-grow bg-card text-card-foreground shadow-sm" id="cellsTable" style=" height: 80vh;">
            <div class="flex justify-end items-center p-4">
                <form action="<?php echo e(route('dashboard')); ?>" method="GET" class="flex space-x-2">
                    <select name="year" class="border rounded-md p-2 text-sm">
                        <option value="" disabled <?php echo e(!$selectedYear ? 'selected' : ''); ?>>Filter by Report Year
                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($year); ?>" <?php echo e($selectedYear == $year ? 'selected' : ''); ?>>
                            <?php echo e($year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="submit" class="bg-blue-500 text-white rounded p-2">Filter</button>
                </form>
            </div>
            <div class="overflow-auto border-2 border-black" style="max-height: 100%;">
                <table class="w-full table-auto">
                    <thead class="bg-slate-400 sticky top-0 left-0">
                        <tr>
                            <!-- Only show the "Municipality" header if the user is a super_admin -->
                            <?php if(auth()->user()->role === 'super_admin'): ?>
                                <th class="p-4 border-3 border-zinc-800" style="width: 100px;">Municipality</th>
                            <?php endif; ?>

                            <!-- Display month headers for all users -->
                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="p-4 border-3 border-zinc-800" style="width: 100px;">
                                    <?php echo e(substr($month, 0, 3)); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $municipalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(auth()->user()->role === 'super_admin' || auth()->user()->municipality === $municipality): ?>
                                <tr>
                                    <?php if(auth()->user()->role === 'super_admin'): ?>
                                        <td class="p-4 border border-zinc-800" style="width: 200px;">
                                            <?php echo e($municipality); ?>

                                        </td>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="p-2 text-center border border-zinc-800 bg-slate-200"
                                            style="width: 100px;">

                                            <?php if(
                                                $files->contains(function ($file) use ($municipality, $month) {
                                                    $selectedMonths = json_decode($file->selected_months, true);
                                                    return $file->municipality === $municipality && in_array($month, $selectedMonths);
                                                })): ?>
                                                <img src="<?php echo e(asset('storage/images/checked.png')); ?>" alt="Check"
                                                    style="width: 20px; height: 20px;" class="mx-auto" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('storage/images/cancel.png')); ?>" alt="Check"
                                                    style="width: 20px; height: 20px;" class="mx-auto" />
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>


    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mon\Desktop\FHSIS\resources\views/dashboard.blade.php ENDPATH**/ ?>