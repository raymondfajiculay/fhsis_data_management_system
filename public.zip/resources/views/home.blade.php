<x-layout>

    <div
        class="mx-auto flex w-full mt-20 flex-col justify-center px-5 pt-0 md:h-[unset] md:max-w-[92%] lg:max-w-[80%] lg:px-6 xl:pl-0">
        <div class="relative flex w-full flex-col pt-[20px] md:pt-0">
            <h1>Landing Page</h1>
        </div>
    </div>
</x-layout>
